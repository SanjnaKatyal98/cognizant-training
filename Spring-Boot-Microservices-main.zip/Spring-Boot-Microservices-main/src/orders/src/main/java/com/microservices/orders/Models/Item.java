package com.microservices.orders.Models;

public class Item {
    private Integer id;
    private int quantity;
    private Double total_product_price;
}
