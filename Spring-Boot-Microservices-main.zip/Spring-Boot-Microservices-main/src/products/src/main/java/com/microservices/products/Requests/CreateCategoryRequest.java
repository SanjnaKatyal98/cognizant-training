package com.microservices.products.Requests;

public record CreateCategoryRequest(Integer id, String name) {
}
