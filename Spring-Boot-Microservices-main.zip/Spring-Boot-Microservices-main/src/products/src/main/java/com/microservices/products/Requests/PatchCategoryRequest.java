package com.microservices.products.Requests;

public record PatchCategoryRequest(Integer id, String name) {
}
