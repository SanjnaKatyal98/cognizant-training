package com.microservices.user.Models;

public enum Role {
    CUSTOMER,
    ADMIN
}
