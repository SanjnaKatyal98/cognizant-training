// src/main/java/com/bankingapp/controllers/TransferController.java
package com.bankingapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bankingapp.models.TransferDetails;
import com.bankingapp.repositories.TransferRepository;

@RestController
@RequestMapping("/api/transfers")
public class TransferController {
    @Autowired
    private TransferRepository transferRepository;

    @PostMapping
    public TransferDetails transferFunds(@RequestBody TransferDetails transferDetails) {
        return transferRepository.save(transferDetails);
    }
}
