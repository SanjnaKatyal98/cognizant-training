// src/main/java/com/bankingapp/models/Transaction.java
package com.bankingapp.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDate;

@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String accountName;
    private Double amount;
    private LocalDate date;

    // Constructors, Getters, and Setters
}
