// src/main/java/com/bankingapp/repositories/AccountRepository.java
package com.bankingapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bankingapp.models.Account;

public interface AccountRepository extends JpaRepository<Account, Long> {}
