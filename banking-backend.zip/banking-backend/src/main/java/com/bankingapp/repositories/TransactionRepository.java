// src/main/java/com/bankingapp/repositories/TransactionRepository.java
package com.bankingapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bankingapp.models.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {}
