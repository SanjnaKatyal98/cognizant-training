// src/main/java/com/bankingapp/repositories/TransferRepository.java
package com.bankingapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bankingapp.models.TransferDetails;

public interface TransferRepository extends JpaRepository<TransferDetails, Long> {}
