package com.bankingapp.banking_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
