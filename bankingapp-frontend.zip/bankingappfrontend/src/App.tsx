import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState } from 'react';
import Login from './components/Login';
import Header from './components/Header';
import AccountService from './components/AccountService';
import TransactionService from './components/TransactionService';
import FundTransferService from './components/FundTransferService';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = (username: string, password: string) => {
    if (username === 'user' && password === 'password') {
      setIsLoggedIn(true);
    } else {
      alert('Invalid credentials');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {isLoggedIn ? (
        <>
          <Header />
          <main className="container mx-auto p-4">
            <AccountService />
            <TransactionService />
            <FundTransferService />
          </main>
        </>
      ) : (
        <Login onLogin={handleLogin} />
      )}
    </div>
  );
};

export default App;