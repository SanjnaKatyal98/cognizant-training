import React from 'react';
import { Account } from '../types';

const AccountService: React.FC = () => {
  const accounts: Account[] = [
    { id: 1, name: 'John Doe', balance: 5000 },
    { id: 2, name: 'Jane Smith', balance: 3000 }
  ];

  return (
    <section className="mb-8">
      <h2 className="text-xl font-bold mb-4">Accounts</h2>
      <ul className="bg-white p-4 rounded shadow">
        {accounts.map((account) => (
          <li key={account.id} className="mb-2 flex justify-between">
            <span>{account.name}</span>
            <span>${account.balance}</span>
          </li>
        ))}
      </ul>
    </section>
  );
};

export default AccountService;