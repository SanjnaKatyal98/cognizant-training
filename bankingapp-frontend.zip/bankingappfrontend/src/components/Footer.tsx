const Footer = () => {
    const copyrightYear = 2024;
  const devName = "Sanjna";

  return (
    <div className="text-align: center">
      <hr />
       <p>Copyright{copyrightYear}|@{devName}</p>
    </div>
  )
}

export default Footer