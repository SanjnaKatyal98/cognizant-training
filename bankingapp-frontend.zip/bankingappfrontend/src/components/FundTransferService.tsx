import React, { useState } from 'react';
import { TransferDetails } from '../types';

const FundTransferService: React.FC = () => {
  const [transferDetails, setTransferDetails] = useState<TransferDetails>({
    from: '',
    to: '',
    amount: 0,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setTransferDetails({ ...transferDetails, [name]: value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Transfer Details:', transferDetails);
  };

  return (
    <section className="mb-8">
      <h2 className="text-xl font-bold mb-4">Fund Transfer</h2>
      <form onSubmit={handleSubmit} className="bg-white p-4 rounded shadow">
        <input
          type="text"
          name="from"
          placeholder="From Account"
          value={transferDetails.from}
          onChange={handleChange}
          className="w-full p-2 border rounded mb-4"
        />
        <input
          type="text"
          name="to"
          placeholder="To Account"
          value={transferDetails.to}
          onChange={handleChange}
          className="w-full p-2 border rounded mb-4"
        />
        <input
          type="number"
          name="amount"
          placeholder="Amount"
          value={transferDetails.amount}
          onChange={handleChange}
          className="w-full p-2 border rounded mb-4"
        />
        <button type="submit" className="bg-blue-600 text-white p-2 rounded">Transfer</button>
      </form>
    </section>
  );
};

export default FundTransferService;