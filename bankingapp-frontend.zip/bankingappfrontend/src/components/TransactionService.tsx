import React from 'react';
import { Transaction } from '../types';

const TransactionService: React.FC = () => {
  const transactions: Transaction[] = [
    { id: 1, account: 'John Doe', amount: -200, date: '2024-10-01' },
    { id: 2, account: 'Jane Smith', amount: 500, date: '2024-10-02' },
  ];

  return (
    <section className="mb-8">
      <h2 className="text-xl font-bold mb-4">Transactions</h2>
      <ul className="bg-white p-4 rounded shadow">
        {transactions.map((transaction) => (
          <li key={transaction.id} className="mb-2 flex justify-between">
            <span>{transaction.account}</span>
            <span>{transaction.amount > 0 ? '+' : ''}${transaction.amount}</span>
            <span>{transaction.date}</span>
          </li>
        ))}
      </ul>
    </section>
  );
};

export default TransactionService;