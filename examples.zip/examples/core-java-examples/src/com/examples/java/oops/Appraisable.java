package com.examples.java.oops;

public interface Appraisable {
	public void appraise();
}
