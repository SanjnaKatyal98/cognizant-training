package com.examples.design.patterns.behavioral.command;

public interface Order {
    void execute();
}
