package com.examples.design.patterns.behavioral.interpreter;

public interface Expression {
    public boolean interpret(String context);
}
