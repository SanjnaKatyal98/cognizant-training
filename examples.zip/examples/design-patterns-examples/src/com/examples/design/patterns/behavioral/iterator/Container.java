package com.examples.design.patterns.behavioral.iterator;

public interface Container {
    public Iterator getIterator();
}
