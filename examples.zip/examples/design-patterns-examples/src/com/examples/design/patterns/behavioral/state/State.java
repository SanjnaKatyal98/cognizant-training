package com.examples.design.patterns.behavioral.state;

public interface State {
    public void doAction(Context context);
}
