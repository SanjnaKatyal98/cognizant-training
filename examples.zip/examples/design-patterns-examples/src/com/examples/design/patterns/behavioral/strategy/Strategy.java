package com.examples.design.patterns.behavioral.strategy;

public interface Strategy {
    public int doOperation(int num1, int num2);
}
