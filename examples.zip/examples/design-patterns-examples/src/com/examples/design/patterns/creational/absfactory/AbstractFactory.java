package com.examples.design.patterns.creational.absfactory;

public abstract class AbstractFactory {
    public abstract Shape getShape(String shapeType) ;
}
