package com.examples.design.patterns.creational.absfactory;

public interface Shape {
    void draw();
}
