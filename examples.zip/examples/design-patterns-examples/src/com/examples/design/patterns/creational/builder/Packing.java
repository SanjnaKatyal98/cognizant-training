package com.examples.design.patterns.creational.builder;

public interface Packing {
    public String pack();
}
