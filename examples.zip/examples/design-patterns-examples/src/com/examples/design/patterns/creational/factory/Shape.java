package com.examples.design.patterns.creational.factory;

public interface Shape {
    void draw();
}
