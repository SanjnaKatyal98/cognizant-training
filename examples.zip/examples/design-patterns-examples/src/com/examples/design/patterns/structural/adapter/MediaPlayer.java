package com.examples.design.patterns.structural.adapter;

public interface MediaPlayer {
    public void play(String audioType, String fileName);

}
