package com.examples.design.patterns.structural.bridge;

public interface DrawAPI {
    public void drawCircle(int radius, int x, int y);
}
