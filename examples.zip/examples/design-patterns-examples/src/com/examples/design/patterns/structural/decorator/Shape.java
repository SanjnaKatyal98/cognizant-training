package com.examples.design.patterns.structural.decorator;

public interface Shape {
    void draw();
}
