package com.examples.design.patterns.structural.facade;

public interface Shape {
    void draw();
}
