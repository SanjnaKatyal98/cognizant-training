package com.examples.design.patterns.structural.flyweight;

public interface Shape {
    void draw();
}
