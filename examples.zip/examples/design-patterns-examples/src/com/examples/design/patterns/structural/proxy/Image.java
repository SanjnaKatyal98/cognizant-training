package com.examples.design.patterns.structural.proxy;

public interface Image {
    void display();
}
