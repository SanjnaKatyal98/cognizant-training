package com.examples.design.solid.d.bad;

public class StandardKeyboard  {

}
