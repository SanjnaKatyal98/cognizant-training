package com.examples.design.solid.d.bad;

public class SuperWorker {
    public void work() {
        //.... working much more
    }
}