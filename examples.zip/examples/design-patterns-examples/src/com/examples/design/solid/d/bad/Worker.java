package com.examples.design.solid.d.bad;

// Dependency Inversion Principle - Bad example

public class Worker {
    public void work() {
        // ....working
    }
}
