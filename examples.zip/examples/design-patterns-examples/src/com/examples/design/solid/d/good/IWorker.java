package com.examples.design.solid.d.good;

// Dependency Inversion Principle - Good example
interface IWorker {
    public void work();
}
