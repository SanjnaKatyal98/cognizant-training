package com.examples.design.solid.d.good;

public interface Keyboard {
}
