package com.examples.design.solid.d.good;

public class StandardKeyboard implements Keyboard {

}
