package com.examples.design.solid.d.good;

public class SuperWorker  implements IWorker{
    public void work() {
        //.... working much more
    }
}