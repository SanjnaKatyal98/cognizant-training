package com.examples.design.solid.d.good;

public class Worker implements IWorker{
    public void work() {
        // ....working
    }
}
