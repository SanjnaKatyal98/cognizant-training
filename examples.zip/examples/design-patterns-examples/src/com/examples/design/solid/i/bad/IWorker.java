package com.examples.design.solid.i.bad;

// interface segregation principle - bad example
public interface IWorker {
    public void work();
    public void eat();
}
