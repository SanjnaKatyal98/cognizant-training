package com.examples.design.solid.i.bad;

public class Robot implements IWorker {
    @Override
    public void work() {
        // can do work ultra fast
    }

    @Override
    public void eat() {
        // Not Available
    }
}
