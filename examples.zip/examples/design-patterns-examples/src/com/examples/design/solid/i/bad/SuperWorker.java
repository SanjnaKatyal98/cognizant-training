package com.examples.design.solid.i.bad;

public class SuperWorker implements IWorker{
    public void work() {
        //.... working much more
    }

    public void eat() {
        //.... eating in lunch break
    }
}
