package com.examples.design.solid.i.good;

public interface IFeedable {
    public void eat();
}
