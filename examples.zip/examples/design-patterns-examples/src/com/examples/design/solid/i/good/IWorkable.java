package com.examples.design.solid.i.good;

public interface IWorkable {
    public void work();
}
