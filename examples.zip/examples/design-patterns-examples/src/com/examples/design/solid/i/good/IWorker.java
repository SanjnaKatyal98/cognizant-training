package com.examples.design.solid.i.good;

// interface segregation principle - good example
public interface IWorker extends IFeedable, IWorkable {
}












