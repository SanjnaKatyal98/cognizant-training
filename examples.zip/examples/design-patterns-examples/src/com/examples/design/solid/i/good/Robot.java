package com.examples.design.solid.i.good;

public class Robot implements IWorkable{
    public void work() {
        // ....working
    }
}
