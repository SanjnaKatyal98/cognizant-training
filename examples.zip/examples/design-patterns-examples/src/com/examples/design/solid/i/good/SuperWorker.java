package com.examples.design.solid.i.good;

public class SuperWorker implements IWorker { //IWorkable, IFeedable{
    public void work() {
        //.... working much more
    }

    public void eat() {
        //.... eating in launch break
    }
}
