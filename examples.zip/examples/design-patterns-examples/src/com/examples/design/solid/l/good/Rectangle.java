package com.examples.design.solid.l.good;

public class Rectangle extends Shape
{
    public int getArea(){
        return m_width * m_height;
    }
}

