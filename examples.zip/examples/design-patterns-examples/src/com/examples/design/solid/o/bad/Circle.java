package com.examples.design.solid.o.bad;

public class Circle extends Shape {
    Circle() {
        super.m_type=2;
    }
}