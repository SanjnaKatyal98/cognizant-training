package com.examples.design.solid.o.bad;

public class Rectangle extends Shape {
    Rectangle() {
        super.m_type=1;
    }
}
