package com.examples.design.solid.o.bad;

public class Shape {
    int m_type;
}
