package com.examples.design.solid.o.good;

public class Rectangle extends Shape  {
    public void draw() {
        // draw the rectangle
        System.out.println("Drawing rectangle...");
    }
}
