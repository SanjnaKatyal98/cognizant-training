package com.examples.design.solid.o.good;

public abstract class Shape {
    abstract void draw();
}
