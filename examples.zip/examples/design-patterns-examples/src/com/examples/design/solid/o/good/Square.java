package com.examples.design.solid.o.good;

public class Square extends Shape  {
    public void draw() {
        // draw the rectangle
        System.out.println("Drawing Square...");
    }
}
