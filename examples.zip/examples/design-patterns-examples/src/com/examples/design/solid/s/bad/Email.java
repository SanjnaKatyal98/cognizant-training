package com.examples.design.solid.s.bad;

public class Email implements IEmail {
    public void setSender(String sender) { } // set sender;
    public void setReceiver(String receiver) { } // set receiver;
    public void setContent(String content) { } // set content;
}
