package com.examples.design.solid.s.good;

public class Email implements IEmail {
    public void setSender(String sender) { } // set sender;
    public void setReceiver(String receiver) { } // set receiver;
    public void setContent(IContent content) { } // set content;
}
