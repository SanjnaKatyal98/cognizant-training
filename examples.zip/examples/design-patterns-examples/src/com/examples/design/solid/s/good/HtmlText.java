package com.examples.design.solid.s.good;

public class HtmlText implements IContent{
    @Override
    public String getAsString() {
        return "<html><body>Hello VMWare!!!</bod></html>";
    }
}
