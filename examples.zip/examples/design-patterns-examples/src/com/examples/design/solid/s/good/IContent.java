package com.examples.design.solid.s.good;

public interface IContent {
    public String getAsString(); // used for serialization
}
