package com.examples.design.solid.s.good;

public class PlainText implements IContent {
    @Override
    public String getAsString() {
        return "Hello VMWare!!!";
    }
}
