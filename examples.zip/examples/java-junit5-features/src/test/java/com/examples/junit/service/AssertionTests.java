package com.examples.junit.service;

public class AssertionTests {
}
