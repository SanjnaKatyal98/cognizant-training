package com.examples.junit.mockito;

public interface DeliveryPlatform {
    void deliver(Email email);
}
