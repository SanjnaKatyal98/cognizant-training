package com.examples.junit.mockito;

public enum Format {
    TEXT_ONLY, HTML;
}
