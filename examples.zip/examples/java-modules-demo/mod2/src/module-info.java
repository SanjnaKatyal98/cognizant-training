module mod2 {
    requires mod1;
    uses com.labs.java.module.product.service.ProductService;
}