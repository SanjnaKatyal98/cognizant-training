package com.examples.reactive.java.flow;

public class VideoFrame {
    private long number;
    // additional data fields

    public VideoFrame(long number) {
        this.number = number;
    }

    public long getNumber() {
        return number;
    }

    public void setNumber(long number) {
        this.number = number;
    }


    // constructor, getters, setters
}
