package com.examples.sboot.lombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbootLombokDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
