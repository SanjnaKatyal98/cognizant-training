package com.labs.sboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbootOrderRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbootOrderRestApiApplication.class, args);
	}

}
