package com.examples.scart.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ShoppingCartAdminApplicationTests {

	@Test
	public void contextLoads() {
	}

}
