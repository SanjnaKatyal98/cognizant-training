package com.examples.scart.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CustomerServiceMainTests {

	@Test
	public void contextLoads() {
		
	}

}
