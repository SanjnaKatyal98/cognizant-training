package com.examples.scart.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingCartApiGateway {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingCartApiGateway.class, args);
	}

}
