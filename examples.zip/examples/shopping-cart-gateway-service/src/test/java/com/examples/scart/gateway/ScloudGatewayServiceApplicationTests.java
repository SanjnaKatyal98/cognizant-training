package com.examples.scart.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScloudGatewayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
