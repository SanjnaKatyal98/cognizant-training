let message = 'Welcome to Node JS';
console.log(message);