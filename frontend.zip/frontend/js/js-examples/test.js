var retirementAge = 60;
getServiceLeft(32);
function getServiceLeft(age){
  console.log(retirementAge-age);
}