// Arithmetic   => + - * / % ++ --
// Relational   => == === < <= > >= != !==
// Logical      => && || !
// Assignment   => = += -= *= /=
// Bitwise      => & | ! << <<< >> 
// Conditional
// typeof
// instanceof

// let a = 10;
// let b = 20;
// console.log(a + b);

// Type Coersion
let a = 50;
let b = 100;
let c = a + b;

console.log(typeof a);
console.log(typeof b);
console.log(typeof c);

console.log(c);

// TRUTHY
// FALSY - 0, false, undefined, null, ''
if(a == b || b > 10) {
    console.log("TRUE " + c);
} else {
    console.log("FALSE " + c);
}


