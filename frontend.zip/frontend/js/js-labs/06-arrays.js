
let skills = ['Java', 'SpringBoot', {'id':100,'dept':'IT'}, 'ReactJS'];

console.log(skills);

skills[0] = '';
// skills[2] = 'Node';
console.log(skills[0]);
console.log(skills[2]);

// add / remove in the end
skills.pop();
skills.push('JavaScript');

console.log(skills);

// add /remove in the beginning
skills.shift
skills.unshift

