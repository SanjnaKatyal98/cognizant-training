// Template Literal

let header = `<header>
                <nav>
                    <ul> <li> Home </li> <li> About Us </li> </ul>
                </nav>
              </header>`;
console.log(header);

// Template Strings
let amount = 10000,
    id = 123,
    message = `Amount ${amount} deposited successfully into account ${id}`;

console.log(message);

