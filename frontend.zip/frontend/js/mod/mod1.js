export const greetings = "Hello!!!"
console.log(greetings)

