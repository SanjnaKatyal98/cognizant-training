import {greetings} from './mod1'

console.log(greetings)