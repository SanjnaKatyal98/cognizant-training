// math.js

// Function to add two numbers
export function add(a, b) {
  return a + b;
}

// Function to subtract two numbers
 function subtract(a, b) {
  return a - b;
}

export default function(a,b) {
  return a * b;
}

var div = function(a,b) {
  return a / b;
}

export {subtract, div as division};



