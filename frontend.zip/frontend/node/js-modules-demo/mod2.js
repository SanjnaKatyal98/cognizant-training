// Name Import
import {greetings} from './mod1.js'

// Default Import
import test from './mod1.js'

// // Name Import
import {test1} from './mod1.js'

// // List Import
import {greetings1, greetings2} from './mod1.js'

console.log(greetings)
console.log(test)
console.log(test1)
console.log(`${greetings1} ${greetings2} `)