import React from "react";

// Class Component example
class HomePage extends React.Component {
  
  render() {
    return  <main className='text-center'>
              <p>Welcome to React Learning!!!</p>
            </main>;

  }

}

export default HomePage;
