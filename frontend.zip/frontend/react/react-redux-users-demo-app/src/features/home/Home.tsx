const Home = () => {
  return (
    <>
      <h1>Welcome to Redux app</h1>
    </>
  )
}

export default Home