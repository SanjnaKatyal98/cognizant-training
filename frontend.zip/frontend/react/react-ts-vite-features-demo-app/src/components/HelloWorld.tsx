const HelloWorld = () => {
  return (
    <section>
      <p>Hello World Component</p>
    </section>
  );
};

export default HelloWorld;
