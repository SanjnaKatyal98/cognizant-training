export default interface IGreetings {
  name: string;
  message?: string;
}

//export default IGreetings;
