"use strict";
console.log("Hello World"); // This is valid in TS 
