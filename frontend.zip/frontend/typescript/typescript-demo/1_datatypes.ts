
// Type Inference
var a = 100;

// Explicit Type Declaration
var b = 200;

//var c:string = null;

// console.log(typeof a);

// Not allowed in typescript

// a = 100;
// b = 200;

// Not allowed in typescript
// a = 'Hello';

console.log(a + b);
// console.log(c);