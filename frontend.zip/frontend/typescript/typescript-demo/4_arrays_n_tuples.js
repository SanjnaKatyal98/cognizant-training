"use strict";
//Arrays
let myArr = ["Football", "Cricket", 1, true]; // Array with elements of any data type
console.log(myArr);
// myArr = [ 300, 400 ]; //will work
// let myArr1: number[] = [10, 20, 30]; // array of numbers
// //Another way is 
let list = [1, 2, 3]; //array of numbers
console.log(list);
// // Check the following example
let myArr2 = ["ABC", 123];
// myArr2 = 'Hello';
//myArr2 = ["ABC", 123]; // will throw an error as the array element should match the data type specified.
// This is Tuple. Tuple is a data structure consisting of multiple parts.
