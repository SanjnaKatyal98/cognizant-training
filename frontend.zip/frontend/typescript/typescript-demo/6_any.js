"use strict";
//any data type
let details = "Test"; //specifying any data type
details = 23;
let random = "test"; // any data type
console.log(typeof random);
random = 100;
console.log(typeof random);
//array of any type
let newArr = ["wow", 0, true, "test"]; //array of any data type
