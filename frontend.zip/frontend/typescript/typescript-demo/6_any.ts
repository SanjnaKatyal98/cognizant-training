//any data type
let details: any = "Test"; //specifying any data type
details = 23;


let random: any = "test";  // any data type
console.log(typeof random);
random = 100;
console.log(typeof random);

//array of any type
let newArr: any[] = [ "wow", 0, true, "test"]; //array of any data type
