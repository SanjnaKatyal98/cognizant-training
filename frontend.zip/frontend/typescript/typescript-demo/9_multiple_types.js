"use strict";
// When we want to have two different types of values 
let goals = 5; // either number or string
goals = "5";
goals = 6;
console.log(goals);
